package com.example.vyanktesh.amesh;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import static android.support.v4.content.ContextCompat.startActivity;

public class UserPanel extends AppCompatActivity {

    DatabaseReference userlogin;
    RecyclerView recyclerView;
    Toolbar toolo;
    List<TransactionentryModel> Transactioninv=new ArrayList<>();
    List<DataSnapshot> fullgroupdata=new ArrayList<>();
    List<String> uidis=new ArrayList<>();
    List<String> Tidids=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_panel);
        toolo=findViewById(R.id.toolb);
        setSupportActionBar(toolo);
        getSupportActionBar().setTitle("User Panel");
        recyclerView=findViewById(R.id.recylo);
//        userlogin=FirebaseDatabase.getInstance().getReference("Allgroups").child(groumo.getText().toString()).child(youmono.getText().toString());
        String userid=getIntent().getStringExtra("userid");
        String grouopid=getIntent().getStringExtra("grouopid");
        final String partytype=getIntent().getStringExtra("partytype");

        if (userid.equals(grouopid)){
            readdata(FirebaseDatabase.getInstance().getReference("Allgroups").child(userid), new OnGetDataListner() {
                @Override
                public void onSuccess(DataSnapshot dataSnapshot) {
                    uidis.clear();
                    Tidids.clear();
                    fullgroupdata.clear();
                    Transactioninv.clear();
                    for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                        fullgroupdata.add(dataSnapshot1);
                        uidis.add(dataSnapshot1.getKey());
                    }
                    for (int i=0;i<fullgroupdata.size();i++){
                        for (DataSnapshot dataSnapshot2:fullgroupdata.get(i).getChildren()){
                            Tidids.add(dataSnapshot2.getKey());
                        }
                    }
                    for (int i = 0; i <= Tidids.size() - 1; i++) {
                        readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tidids.get(i)), new OnGetDataListner() {
                            @Override
                            public void onSuccess(DataSnapshot dataSnapshot) {
                                Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
                                Log.d("tranv", "" + Transactioninv.size());
                                Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
                                recyclerView.setLayoutManager(new LinearLayoutManager(UserPanel.this));
                                recyclerView.setAdapter(new useradapter(Transactioninv,UserPanel.this,Tidids,partytype));
                            }

                            @Override
                            public void onStart() {

                            }

                            @Override
                            public void onFailure() {

                            }
                        });
                    }
                }

                @Override
                public void onStart() {

                }

                @Override
                public void onFailure() {

                }
            });
        }else {
            readdata(FirebaseDatabase.getInstance().getReference("Allgroups").child(grouopid).child(userid), new OnGetDataListner() {
                @Override
                public void onSuccess(DataSnapshot dataSnapshot) {
                    uidis.clear();
                    Tidids.clear();
                    fullgroupdata.clear();
                    Transactioninv.clear();
                    for (DataSnapshot dataSnapshot2:dataSnapshot.getChildren()){
                        Tidids.add(dataSnapshot2.getKey());
                    }
                    for (int i = 0; i <= Tidids.size() - 1; i++) {
                        readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tidids.get(i)), new OnGetDataListner() {
                            @Override
                            public void onSuccess(DataSnapshot dataSnapshot) {
                                Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
                                Log.d("tranv", "" + Transactioninv.size());
                                Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
                                recyclerView.setLayoutManager(new LinearLayoutManager(UserPanel.this));
                                recyclerView.setAdapter(new useradapter(Transactioninv,UserPanel.this,Tidids,partytype));
                            }

                            @Override
                            public void onStart() {

                            }

                            @Override
                            public void onFailure() {

                            }
                        });
                    }
                }

                @Override
                public void onStart() {

                }

                @Override
                public void onFailure() {

                }
            });
        }
//        sumi.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Tidls.clear();
//                Transactioninv.clear();
//                readdata(FirebaseDatabase.getInstance().getReference("Allgroups").child(groumo.getText().toString()).child(youmono.getText().toString()), new OnGetDataListner() {
//                    @Override
//                    public void onSuccess(DataSnapshot dataSnapshot) {
//                        Tidls.clear();
//                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                            Tidls.add(dataSnapshot2.getKey());
//                        }
//                        Log.d("tidsize", "" + Tidls.size());
//                        for (int i = 0; i <= Tidls.size() - 1; i++) {
//                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tidls.get(i)), new OnGetDataListner() {
//                                @Override
//                                public void onSuccess(DataSnapshot dataSnapshot) {
//                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
//                                    Log.d("tranv", "" + Transactioninv.size());
//                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
//                                    recyclerView.setLayoutManager(new LinearLayoutManager(UserPanel.this));
//                                    recyclerView.setAdapter(new Searchadapter(Transactioninv,UserPanel.this));
//                                }
//
//                                @Override
//                                public void onStart() {
//
//                                }
//
//                                @Override
//                                public void onFailure() {
//
//                                }
//                            });
//                        }
//                        Log.d("ter", "" + Transactioninv.size());
////
//                    }
//
//                    @Override
//                    public void onStart() {
//
//                    }
//
//                    @Override
//                    public void onFailure() {
//
//                    }
//                });
////                readdata(userlogin, new OnGetDataListner() {
////                    @Override
////                    public void onSuccess(DataSnapshot dataSnapshot) {
////                        for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
////                            Tidls.add(dataSnapshot1.getKey());
////                            Log.d("diwu",""+dataSnapshot1.getKey());
////                        }
////                        for (int i=0;i<=Tidls.size()-1;i++){
////                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tidls.get(i)), new OnGetDataListner() {
////                                @Override
////                                public void onSuccess(DataSnapshot dataSnapshot) {
////                                   Log.d("heio",""+dataSnapshot.getKey());
////                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
////                                    Log.d("eui",""+Transactioninv.size());
////                                    Log.d("ioeu",""+Transactioninv.get(0).maturitydateedit);
////                                    recyclerView.setLayoutManager(new LinearLayoutManager(UserPanel.this));
////                                    recyclerView.setAdapter(new Searchadapter(Transactioninv,UserPanel.this));
////                                }
////
////                                @Override
////                                public void onStart() {
////
////                                }
////
////                                @Override
////                                public void onFailure() {
////
////                                }
////                            });
////                        }
////                    }
////
////                    @Override
////                    public void onStart() {
////
////                    }
////
////                    @Override
////                    public void onFailure() {
////
////                    }
////                });
//            }
//        });
    }
    public void readdata(final DatabaseReference reference, final OnGetDataListner listner){
        listner.onStart();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listner.onSuccess(dataSnapshot);
//                reference.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        listner.onSuccess(dataSnapshot);
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//                        listner.onFailure();
//                    }
//                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
