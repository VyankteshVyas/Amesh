package com.example.vyanktesh.amesh;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Searchactivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private static final String TAG = "MainActivity";
    int i;
    Spinner investorspinner,recieverspinner;
    CheckBox investorcheckbox,recievercheckbox,maturitydatecheckbox,entrydatecheckbox;
    TextView entrydate,matyritydate;
    Toolbar toolo;
    ProgressBar progibar;
    String currentDateString;
    AutoCompleteTextView searchi;
    DatabaseReference Investors,Recievers;
    RecyclerView reciv;
    Spinner searchwaySpinner;

    Button seli,show,search;
    List<String> investorgroupid=new ArrayList<>();
    List<String> investoruserid=new ArrayList<>();
    List<String> investori=new ArrayList<>();
    List<String> recievergroupid=new ArrayList<>();
    List<String> recieveruserid=new ArrayList<>();
    List<String> recieveri=new ArrayList<>();
    List<String> Tids=new ArrayList<>();
    List<TransactionentryModel> Transactioninv=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchactivity);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        investorspinner=findViewById(R.id.investorspinner);
        recieverspinner=findViewById(R.id.recieverspinner);
        entrydate=findViewById(R.id.entrydatetextview);
        matyritydate=findViewById(R.id.maturitydatetextview);
        investorcheckbox=findViewById(R.id.investorcheckBox);
        recievercheckbox=findViewById(R.id.revievercheckBox2);
        entrydatecheckbox=findViewById(R.id.EntrydatecheckBox7);
        maturitydatecheckbox=findViewById(R.id.MaturitydatecheckBox6);


        reciv=findViewById(R.id.reciv);
//        seli=findViewById(R.id.seli);
//        show=findViewById(R.id.show);
        search=findViewById(R.id.search);
//        searchi=findViewById(R.id.searchbar);
//        searchwaySpinner=findViewById(R.id.searchwayspin);
        progibar=findViewById(R.id.progibar);
        progibar.setIndeterminate(true);
        progibar.setVisibility(View.INVISIBLE);
        Investors= FirebaseDatabase.getInstance().getReference("Investors");
        toolo=findViewById(R.id.toolb);
        setSupportActionBar(toolo);
        getSupportActionBar().setTitle("Search Deals");
        Recievers=FirebaseDatabase.getInstance().getReference("Recievers");
//        searchwaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String selectedItem = parent.getItemAtPosition(position).toString();
//                if (selectedItem.equals("Investor")){
//                    Log.d("haa","hoo");
//                    progibar.setVisibility(View.VISIBLE);
//                    readdata(Investors, new OnGetDataListner() {
//                        @Override
//                        public void onSuccess(DataSnapshot dataSnapshot) {
//                            Log.d("dssd",""+dataSnapshot.getChildrenCount());
//                            investori.clear();
//                            investorgroupid.clear();
//                            investoruserid.clear();
//                            for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
//                                InvestorMode invo=dataSnapshot1.getValue(InvestorMode.class);
//                                Log.d("fdd",dataSnapshot1.getKey());
//                                investori.add(invo.userName);
//                                Log.d("invosize",""+investori.size());
//                                investoruserid.add(dataSnapshot1.getKey());
//                                investorgroupid.add(invo.Groupid);
//                            }
//                            progibar.setVisibility(View.INVISIBLE);
//                            show.setVisibility(View.VISIBLE);
//                        }
//
//                        @Override
//                        public void onStart() {
//
//                        }
//
//                        @Override
//                        public void onFailure() {
//
//                        }
//                    });
//                    Log.d("bhrr","dfd");
//                    Log.d("xdjfk",""+investori.size());
//                    ArrayAdapter investoradapter=new ArrayAdapter(Searchactivity.this,android.R.layout.simple_list_item_1,investori);
//                    Log.d("insa",""+investori.size());
//                    searchi.setAdapter(investoradapter);
//                    searchi.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//
//                        }
//                    });
//                    show.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            if (!TextUtils.isEmpty(searchi.getText().toString())&&investori.contains(searchi.getText().toString())) {
//                                Transactioninv.clear();
//
//                                String inveg = investorgroupid.get(investori.indexOf(searchi.getText().toString()));
//                                String usid = investoruserid.get(investori.indexOf(searchi.getText().toString()));
//                                readdata(FirebaseDatabase.getInstance().getReference("Allgroups").child(inveg).child(usid), new OnGetDataListner() {
//                                    @Override
//                                    public void onSuccess(DataSnapshot dataSnapshot) {
//                                        Tids.clear();
//                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                                            Tids.add(dataSnapshot2.getKey());
//                                        }
//                                        Log.d("tidsize", "" + Tids.size());
//                                        for (i = 0; i <= Tids.size() - 1; i++) {
//                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
//                                                @Override
//                                                public void onSuccess(DataSnapshot dataSnapshot) {
//                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
//                                                    Log.d("tranv", "" + Transactioninv.size());
//                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
//                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
//                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
//                                                }
//
//                                                @Override
//                                                public void onStart() {
//
//                                                }
//
//                                                @Override
//                                                public void onFailure() {
//
//                                                }
//                                            });
//                                        }
//                                        Log.d("ter", "" + Transactioninv.size());
////
//                                    }
//
//                                    @Override
//                                    public void onStart() {
//
//                                    }
//
//                                    @Override
//                                    public void onFailure() {
//
//                                    }
//                                });
//
//                            }else {
//                                Toast.makeText(Searchactivity.this,"Select from options",Toast.LENGTH_LONG).show();}
//                        }
//                    });
//
//                }
//
//
//
//
//
//                if (selectedItem.equals("Reciever")){
//                    Log.d("haa","hoo");
//                    progibar.setVisibility(View.VISIBLE);
//                    readdata(Recievers, new OnGetDataListner() {
//                        @Override
//                        public void onSuccess(DataSnapshot dataSnapshot) {
//                            Log.d("dssd",""+dataSnapshot.getChildrenCount());
//                            investori.clear();
//                            investorgroupid.clear();
//                            investoruserid.clear();
//                            for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
//                                InvestorMode invo=dataSnapshot1.getValue(InvestorMode.class);
//                                Log.d("fdd",dataSnapshot1.getKey());
//                                investori.add(invo.userName);
//                                Log.d("invosize",""+investori.size());
//                                investoruserid.add(dataSnapshot1.getKey());
//                                investorgroupid.add(invo.Groupid);
//                            }
//                            progibar.setVisibility(View.INVISIBLE);
//                            show.setVisibility(View.VISIBLE);
//                        }
//
//                        @Override
//                        public void onStart() {
//
//                        }
//
//                        @Override
//                        public void onFailure() {
//
//                        }
//                    });
//                    Log.d("bhrr","dfd");
//                    Log.d("xdjfk",""+investori.size());
//                    ArrayAdapter investoradapter=new ArrayAdapter(Searchactivity.this,android.R.layout.simple_list_item_1,investori);
//                    Log.d("insa",""+investori.size());
//                    searchi.setAdapter(investoradapter);
//                    searchi.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//
//                        }
//                    });
//                    show.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            Log.d("oneline","abe");
//                            if (!TextUtils.isEmpty(searchi.getText().toString())&&investori.contains(searchi.getText().toString())) {
//                                Transactioninv.clear();
//                                String inveg = investorgroupid.get(investori.indexOf(searchi.getText().toString()));
//                                String usid = investoruserid.get(investori.indexOf(searchi.getText().toString()));
//                                Log.d("twoline","abee");
//                                readdata(FirebaseDatabase.getInstance().getReference("Allgroups").child(inveg).child(usid), new OnGetDataListner() {
//                                    @Override
//                                    public void onSuccess(DataSnapshot dataSnapshot) {
//                                        Tids.clear();
//                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                                            Log.d("three",""+dataSnapshot2.getKey());
//                                            Tids.add(dataSnapshot2.getKey());
//                                        }
//                                        Log.d("tidsize", "" + Tids.size());
//                                        for (i = 0; i <= Tids.size() - 1; i++) {
//                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
//                                                @Override
//                                                public void onSuccess(DataSnapshot dataSnapshot) {
//                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
//                                                    Log.d("tranv", "" + Transactioninv.size());
//                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
//                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
//                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
//                                                }
//
//                                                @Override
//                                                public void onStart() {
//
//                                                }
//
//                                                @Override
//                                                public void onFailure() {
//
//                                                }
//                                            });
//                                        }
//                                        Log.d("ter", "" + Transactioninv.size());
////
//                                    }
//
//                                    @Override
//                                    public void onStart() {
//
//                                    }
//
//                                    @Override
//                                    public void onFailure() {
//
//                                    }
//                                });
//
//                            }
//                        }
//                    });
//
//                }
//
//
//
//
//
//
//
//                if (selectedItem.equals("Entry Date")){
//                    show.setVisibility(View.VISIBLE);
//                    searchi.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            mDateSetListener = new DatePickerDialog.OnDateSetListener() {
//                                @Override
//                                public void onDateSet(DatePicker datePicker, int year, int month, int day) {
//                                    month = month + 1;
//                                    Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);
//
//                                    String date = day + "-" + month + "-" + year;
//                                    searchi.setText(date);
//                                }
//                            };
//                            newdafor();
//                        }
//                    });
//                    show.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            if (!TextUtils.isEmpty(searchi.getText().toString())) {
//                                Transactioninv.clear();
//
//                                readdata(FirebaseDatabase.getInstance().getReference("Entry Dates").child(searchi.getText().toString()), new OnGetDataListner() {
//                                    @Override
//                                    public void onSuccess(DataSnapshot dataSnapshot) {
//                                        Tids.clear();
//                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                                            Tids.add(dataSnapshot2.getValue(String.class));
//                                        }
//                                        Log.d("tidsize", "" + Tids.size());
//                                        for (i = 0; i <= Tids.size() - 1; i++) {
//                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
//                                                @Override
//                                                public void onSuccess(DataSnapshot dataSnapshot) {
//                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
//                                                    Log.d("tranv", "" + Transactioninv.size());
//                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
//                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
//                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
//                                                }
//
//                                                @Override
//                                                public void onStart() {
//
//                                                }
//
//                                                @Override
//                                                public void onFailure() {
//
//                                                }
//                                            });
//                                        }
//                                    }
//
//                                    @Override
//                                    public void onStart() {
//
//                                    }
//
//                                    @Override
//                                    public void onFailure() {
//
//                                    }
//                                });
//                            }
//                        }
//                    });
//                }
//
//
//
//
//
//
//
//
//
//                if (selectedItem.equals("Maturity Date")){
//                    searchi.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            mDateSetListener = new DatePickerDialog.OnDateSetListener() {
//                                @Override
//                                public void onDateSet(DatePicker datePicker, int year, int month, int day) {
//                                    month = month + 1;
//                                    Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);
//
//                                    String date = day + "-" + month + "-" + year;
//                                    searchi.setText(date);
//                                }
//                            };
//                            newdafor();
//                        }
//                    });
//                    show.setVisibility(View.VISIBLE);
//                    show.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            if (!TextUtils.isEmpty(searchi.getText().toString())) {
//                                Transactioninv.clear();
//                                readdata(FirebaseDatabase.getInstance().getReference("Maturity Dates").child(searchi.getText().toString()), new OnGetDataListner() {
//                                    @Override
//                                    public void onSuccess(DataSnapshot dataSnapshot) {
//                                        Tids.clear();
//                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                                            Tids.add(dataSnapshot2.getValue(String.class));
//                                        }
//                                        Log.d("tidsize", "" + Tids.size());
//                                        for (i = 0; i <= Tids.size() - 1; i++) {
//                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
//                                                @Override
//                                                public void onSuccess(DataSnapshot dataSnapshot) {
//                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
//                                                    Log.d("tranv", "" + Transactioninv.size());
//                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
//                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
//                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
//                                                }
//
//                                                @Override
//                                                public void onStart() {
//
//                                                }
//
//                                                @Override
//                                                public void onFailure() {
//
//                                                }
//                                            });
//                                        }
//                                    }
//
//                                    @Override
//                                    public void onStart() {
//
//                                    }
//
//                                    @Override
//                                    public void onFailure() {
//
//                                    }
//                                });
//                            }
//                        }
//                    });
//                }
//
//
//
//
//
//                if (selectedItem.equals("Amount")){
//                    searchi.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//
//                        }
//                    });
//                    show.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            if (!TextUtils.isEmpty(searchi.getText().toString())) {
//                                Transactioninv.clear();
//                                readdata(FirebaseDatabase.getInstance().getReference("Amount Enteries").child(searchi.getText().toString()), new OnGetDataListner() {
//                                    @Override
//                                    public void onSuccess(DataSnapshot dataSnapshot) {
//                                        Tids.clear();
//                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                                            Tids.add(dataSnapshot2.getValue(String.class));
//                                        }
//                                        Log.d("tidsize", "" + Tids.size());
//                                        for (i = 0; i <= Tids.size() - 1; i++) {
//                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
//                                                @Override
//                                                public void onSuccess(DataSnapshot dataSnapshot) {
//                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
//                                                    Log.d("tranv", "" + Transactioninv.size());
//                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
//                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
//                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
//                                                }
//
//                                                @Override
//                                                public void onStart() {
//
//                                                }
//
//                                                @Override
//                                                public void onFailure() {
//
//                                                }
//                                            });
//                                        }
//                                    }
//
//                                    @Override
//                                    public void onStart() {
//
//                                    }
//
//                                    @Override
//                                    public void onFailure() {
//
//                                    }
//                                });
//                            }
//                        }
//                    });
//                }
//
//
//                if (selectedItem.equals("Rate of Intrest")){
//                    searchi.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//
//                        }
//                    });
//                    show.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            if (!TextUtils.isEmpty(searchi.getText().toString())) {
//                                Transactioninv.clear();
//                                readdata(FirebaseDatabase.getInstance().getReference("Rate Of Intrests").child(searchi.getText().toString()), new OnGetDataListner() {
//                                    @Override
//                                    public void onSuccess(DataSnapshot dataSnapshot) {
//                                        Tids.clear();
//                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                                            Tids.add(dataSnapshot2.getValue(String.class));
//                                        }
//                                        Log.d("tidsize", "" + Tids.size());
//                                        for (i = 0; i <= Tids.size() - 1; i++) {
//                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
//                                                @Override
//                                                public void onSuccess(DataSnapshot dataSnapshot) {
//                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
//                                                    Log.d("tranv", "" + Transactioninv.size());
//                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
//                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
//                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
//                                                }
//
//                                                @Override
//                                                public void onStart() {
//
//                                                }
//
//                                                @Override
//                                                public void onFailure() {
//
//                                                }
//                                            });
//                                        }
//                                    }
//
//                                    @Override
//                                    public void onStart() {
//
//                                    }
//
//                                    @Override
//                                    public void onFailure() {
//
//                                    }
//                                });
//                            }
//                        }
//                    });
//                }
//
//
//
//
//
//
//
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });












//        reciv.setLayoutManager(new LinearLayoutManager(this));
//        reciv.setAdapter(new Searchadapter());
//        seli.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                if (searchwaySpinner.getSelectedItem().toString().equals("Investor")){
////                    Log.d("haa","hoo");
////                    progibar.setVisibility(View.VISIBLE);
////                    readdata(Investors, new OnGetDataListner() {
////                        @Override
////                        public void onSuccess(DataSnapshot dataSnapshot) {
////                            Log.d("dssd",""+dataSnapshot.getChildrenCount());
////                            investori.clear();
////                            investorgroupid.clear();
////                            investoruserid.clear();
////                            for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
////                                InvestorMode invo=dataSnapshot1.getValue(InvestorMode.class);
////                                Log.d("fdd",dataSnapshot1.getKey());
////                                investori.add(invo.userName);
////                                Log.d("invosize",""+investori.size());
////                                investoruserid.add(dataSnapshot1.getKey());
////                                investorgroupid.add(invo.Groupid);
////                            }
////                            progibar.setVisibility(View.INVISIBLE);
////                            show.setVisibility(View.VISIBLE);
////                        }
////
////                        @Override
////                        public void onStart() {
////
////                        }
////
////                        @Override
////                        public void onFailure() {
////
////                        }
////                    });
////                    Log.d("bhrr","dfd");
////                    Log.d("xdjfk",""+investori.size());
////                    ArrayAdapter investoradapter=new ArrayAdapter(Searchactivity.this,android.R.layout.simple_list_item_1,investori);
////                    Log.d("insa",""+investori.size());
////                    searchi.setAdapter(investoradapter);
////                    show.setOnClickListener(new View.OnClickListener() {
////                        @Override
////                        public void onClick(View v) {
////                            if (!TextUtils.isEmpty(searchi.getText().toString())&&investori.contains(searchi.getText().toString())) {
////                                Transactioninv.clear();
////
////                                String inveg = investorgroupid.get(investori.indexOf(searchi.getText().toString()));
////                                String usid = investoruserid.get(investori.indexOf(searchi.getText().toString()));
////                                readdata(FirebaseDatabase.getInstance().getReference("Allgroups").child(inveg).child(usid), new OnGetDataListner() {
////                                    @Override
////                                    public void onSuccess(DataSnapshot dataSnapshot) {
////                                        Tids.clear();
////                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
////                                            Tids.add(dataSnapshot2.getKey());
////                                        }
////                                        Log.d("tidsize", "" + Tids.size());
////                                        for (i = 0; i <= Tids.size() - 1; i++) {
////                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
////                                                @Override
////                                                public void onSuccess(DataSnapshot dataSnapshot) {
////                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
////                                                    Log.d("tranv", "" + Transactioninv.size());
////                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
////                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
////                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
////                                                }
////
////                                                @Override
////                                                public void onStart() {
////
////                                                }
////
////                                                @Override
////                                                public void onFailure() {
////
////                                                }
////                                            });
////                                        }
////                                        Log.d("ter", "" + Transactioninv.size());
//////
////                                    }
////
////                                    @Override
////                                    public void onStart() {
////
////                                    }
////
////                                    @Override
////                                    public void onFailure() {
////
////                                    }
////                                });
////
////                            }else {
////                                Toast.makeText(Searchactivity.this,"Select from options",Toast.LENGTH_LONG).show();}
////                        }
////                    });
////
////                }
////                if (searchwaySpinner.getSelectedItem().toString().equals("Reciever")){
////                    Log.d("haa","hoo");
////                    progibar.setVisibility(View.VISIBLE);
////                    readdata(Recievers, new OnGetDataListner() {
////                        @Override
////                        public void onSuccess(DataSnapshot dataSnapshot) {
////                            Log.d("dssd",""+dataSnapshot.getChildrenCount());
////                            investori.clear();
////                            investorgroupid.clear();
////                            investoruserid.clear();
////                            for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
////                                InvestorMode invo=dataSnapshot1.getValue(InvestorMode.class);
////                                Log.d("fdd",dataSnapshot1.getKey());
////                                investori.add(invo.userName);
////                                Log.d("invosize",""+investori.size());
////                                investoruserid.add(dataSnapshot1.getKey());
////                                investorgroupid.add(invo.Groupid);
////                            }
////                            progibar.setVisibility(View.INVISIBLE);
////                            show.setVisibility(View.VISIBLE);
////                        }
////
////                        @Override
////                        public void onStart() {
////
////                        }
////
////                        @Override
////                        public void onFailure() {
////
////                        }
////                    });
////                    Log.d("bhrr","dfd");
////                    Log.d("xdjfk",""+investori.size());
////                    ArrayAdapter investoradapter=new ArrayAdapter(Searchactivity.this,android.R.layout.simple_list_item_1,investori);
////                    Log.d("insa",""+investori.size());
////                    searchi.setAdapter(investoradapter);
////                    show.setOnClickListener(new View.OnClickListener() {
////                        @Override
////                        public void onClick(View v) {
////                            Log.d("oneline","abe");
////                            if (!TextUtils.isEmpty(searchi.getText().toString())&&investori.contains(searchi.getText().toString())) {
////                                Transactioninv.clear();
////                                String inveg = investorgroupid.get(investori.indexOf(searchi.getText().toString()));
////                                String usid = investoruserid.get(investori.indexOf(searchi.getText().toString()));
////                                Log.d("twoline","abee");
////                                readdata(FirebaseDatabase.getInstance().getReference("Allgroups").child(inveg).child(usid), new OnGetDataListner() {
////                                    @Override
////                                    public void onSuccess(DataSnapshot dataSnapshot) {
////                                        Tids.clear();
////                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
////                                            Log.d("three",""+dataSnapshot2.getKey());
////                                            Tids.add(dataSnapshot2.getKey());
////                                        }
////                                        Log.d("tidsize", "" + Tids.size());
////                                        for (i = 0; i <= Tids.size() - 1; i++) {
////                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
////                                                @Override
////                                                public void onSuccess(DataSnapshot dataSnapshot) {
////                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
////                                                    Log.d("tranv", "" + Transactioninv.size());
////                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
////                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
////                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
////                                                }
////
////                                                @Override
////                                                public void onStart() {
////
////                                                }
////
////                                                @Override
////                                                public void onFailure() {
////
////                                                }
////                                            });
////                                        }
////                                        Log.d("ter", "" + Transactioninv.size());
//////
////                                    }
////
////                                    @Override
////                                    public void onStart() {
////
////                                    }
////
////                                    @Override
////                                    public void onFailure() {
////
////                                    }
////                                });
////
////                            }
////                        }
////                    });
////
////                }
////                if (searchwaySpinner.getSelectedItem().toString().equals("Entry Date")){
////                    show.setVisibility(View.VISIBLE);
////                    searchi.setOnClickListener(new View.OnClickListener() {
////                        @Override
////                        public void onClick(View v) {
////                            mDateSetListener = new DatePickerDialog.OnDateSetListener() {
////                                @Override
////                                public void onDateSet(DatePicker datePicker, int year, int month, int day) {
////                                    month = month + 1;
////                                    Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);
////
////                                    String date = day + "-" + month + "-" + year;
////                                    searchi.setText(date);
////                                }
////                            };
////                            newdafor();
////                        }
////                    });
////                    show.setOnClickListener(new View.OnClickListener() {
////                        @Override
////                        public void onClick(View v) {
////                            if (!TextUtils.isEmpty(searchi.getText().toString())) {
////                                Transactioninv.clear();
////
////                                readdata(FirebaseDatabase.getInstance().getReference("Entry Dates").child(searchi.getText().toString()), new OnGetDataListner() {
////                                    @Override
////                                    public void onSuccess(DataSnapshot dataSnapshot) {
////                                        Tids.clear();
////                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
////                                            Tids.add(dataSnapshot2.getValue(String.class));
////                                        }
////                                        Log.d("tidsize", "" + Tids.size());
////                                        for (i = 0; i <= Tids.size() - 1; i++) {
////                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
////                                                @Override
////                                                public void onSuccess(DataSnapshot dataSnapshot) {
////                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
////                                                    Log.d("tranv", "" + Transactioninv.size());
////                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
////                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
////                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
////                                                }
////
////                                                @Override
////                                                public void onStart() {
////
////                                                }
////
////                                                @Override
////                                                public void onFailure() {
////
////                                                }
////                                            });
////                                        }
////                                    }
////
////                                    @Override
////                                    public void onStart() {
////
////                                    }
////
////                                    @Override
////                                    public void onFailure() {
////
////                                    }
////                                });
////                            }
////                        }
////                    });
////                }
//                if (searchwaySpinner.getSelectedItem().toString().equals("Maturity Date")){
//                    searchi.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            mDateSetListener = new DatePickerDialog.OnDateSetListener() {
//                                @Override
//                                public void onDateSet(DatePicker datePicker, int year, int month, int day) {
//                                    month = month + 1;
//                                    Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);
//
//                                    String date = day + "-" + month + "-" + year;
//                                    searchi.setText(date);
//                                }
//                            };
//                            newdafor();
//                        }
//                    });
//                    show.setVisibility(View.VISIBLE);
//                    show.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            if (!TextUtils.isEmpty(searchi.getText().toString())) {
//                                Transactioninv.clear();
//                                readdata(FirebaseDatabase.getInstance().getReference("Maturity Dates").child(searchi.getText().toString()), new OnGetDataListner() {
//                                    @Override
//                                    public void onSuccess(DataSnapshot dataSnapshot) {
//                                        Tids.clear();
//                                        for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                                            Tids.add(dataSnapshot2.getValue(String.class));
//                                        }
//                                        Log.d("tidsize", "" + Tids.size());
//                                        for (i = 0; i <= Tids.size() - 1; i++) {
//                                            readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
//                                                @Override
//                                                public void onSuccess(DataSnapshot dataSnapshot) {
//                                                    Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
//                                                    Log.d("tranv", "" + Transactioninv.size());
//                                                    Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
//                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
//                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
//                                                }
//
//                                                @Override
//                                                public void onStart() {
//
//                                                }
//
//                                                @Override
//                                                public void onFailure() {
//
//                                                }
//                                            });
//                                        }
//                                    }
//
//                                    @Override
//                                    public void onStart() {
//
//                                    }
//
//                                    @Override
//                                    public void onFailure() {
//
//                                    }
//                                });
//                            }
//                        }
//                    });
//                }
//                if (searchwaySpinner.getSelectedItem().toString().equals("Mode")){}
//            }
//        });


























         investorcheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
             @Override
             public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                 progibar.setVisibility(View.VISIBLE);
                 readdata(Investors, new OnGetDataListner() {
                     @Override
                     public void onSuccess(DataSnapshot dataSnapshot) {
                         Log.d("dssd",""+dataSnapshot.getChildrenCount());
                         investori.clear();
                         investorgroupid.clear();
                         investoruserid.clear();
                         for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                             InvestorMode invo=dataSnapshot1.getValue(InvestorMode.class);
                             Log.d("fdd",dataSnapshot1.getKey());
                             investori.add(invo.userName);
                             Log.d("invosize",""+investori.size());
                             investoruserid.add(dataSnapshot1.getKey());
                             investorgroupid.add(invo.Groupid);
                         }
                         investorspinner.setVisibility(View.VISIBLE);
                         ArrayAdapter investoradapter=new ArrayAdapter(Searchactivity.this,android.R.layout.simple_list_item_1,investori);

                         investorspinner.setAdapter(investoradapter);
                         progibar.setVisibility(View.INVISIBLE);
//                         show.setVisibility(View.VISIBLE);
                     }

                     @Override
                     public void onStart() {

                     }

                     @Override
                     public void onFailure() {

                     }
                 });
                 Log.d("bhrr","dfd");
                 Log.d("xdjfk",""+investori.size());
                 Log.d("insa",""+investori.size());


             }
         });
        recievercheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                progibar.setVisibility(View.VISIBLE);
                readdata(Recievers, new OnGetDataListner() {
                    @Override
                    public void onSuccess(DataSnapshot dataSnapshot) {
                        Log.d("dssd",""+dataSnapshot.getChildrenCount());
                        recieveri.clear();
                        recievergroupid.clear();
                        recieveruserid.clear();
                        for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                            InvestorMode invo=dataSnapshot1.getValue(InvestorMode.class);
                            Log.d("fdd",dataSnapshot1.getKey());
                            recieveri.add(invo.userName);
                            Log.d("invosize",""+recieveri.size());
                            recieveruserid.add(dataSnapshot1.getKey());
                            recievergroupid.add(invo.Groupid);
                        }

                        ArrayAdapter recieveradapter=new ArrayAdapter(Searchactivity.this,android.R.layout.simple_list_item_1,recieveri);


                        recieverspinner.setAdapter(recieveradapter);
                        progibar.setVisibility(View.INVISIBLE);
                        recieverspinner.setVisibility(View.VISIBLE);
//                        show.setVisibility(View.VISIBLE);
                    }

                    @Override
                    public void onStart() {

                    }

                    @Override
                    public void onFailure() {

                    }
                });
                Log.d("bhrr","dfd");
                Log.d("xdjfk",""+investori.size());
                Log.d("insa",""+recieveri.size());

            }
        });
        maturitydatecheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                matyritydate.setVisibility(View.VISIBLE);
                matyritydate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                month = month + 1;
                                Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                                String date = day + "-" + month + "-" + year;
                                matyritydate.setText(date);
                            }
                        };
                        newdafor();
                    }
                });
            }
        });
        entrydatecheckbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                entrydate.setVisibility(View.VISIBLE);
                entrydate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                month = month + 1;
                                Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                                String date = day + "-" + month + "-" + year;
                                entrydate.setText(date);
                            }
                        };
                        newdafor();
                    }
                });
            }
        });


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (investorcheckbox.isChecked()||recievercheckbox.isChecked()||entrydatecheckbox.isChecked()||maturitydatecheckbox.isChecked()){
                    if (investorcheckbox.isChecked()){
                        Transactioninv.clear();
                        String inveg = investorgroupid.get(investori.indexOf(investorspinner.getSelectedItem().toString()));
                        String usid = investoruserid.get(investori.indexOf(investorspinner.getSelectedItem().toString()));
                        readdata(FirebaseDatabase.getInstance().getReference("Allgroups").child(inveg).child(usid), new OnGetDataListner() {
                            @Override
                            public void onSuccess(DataSnapshot dataSnapshot) {
                                Tids.clear();
                                for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
                                    Tids.add(dataSnapshot2.getKey());
                                }
                                Log.d("tidsize", "" + Tids.size());
                                for (i = 0; i <= Tids.size() - 1; i++) {
                                    readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
                                        @Override
                                        public void onSuccess(DataSnapshot dataSnapshot) {
                                            Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
                                            Log.d("tranv", "" + Transactioninv.size());
                                            Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
                                            String caso="";
                                            String recieverstring="";
                                            String entrydatestring="";
                                            String maturitystring="";
                                            if (recievercheckbox.isChecked()&&entrydatecheckbox.isChecked()&&maturitydatecheckbox.isChecked()&&!TextUtils.isEmpty(matyritydate.getText().toString())&&!TextUtils.isEmpty(entrydate.getText().toString())){
                                                caso="0";
                                            }
                                            if (recievercheckbox.isChecked()&&entrydatecheckbox.isChecked()&&!TextUtils.isEmpty(entrydate.getText().toString())){
                                                caso="1";
                                            }
                                            if (recievercheckbox.isChecked()&&maturitydatecheckbox.isChecked()&&!TextUtils.isEmpty(matyritydate.getText().toString())){
                                                caso="2";
                                            }
                                            if (entrydatecheckbox.isChecked()&&maturitydatecheckbox.isChecked()&&!TextUtils.isEmpty(matyritydate.getText().toString())&&!TextUtils.isEmpty(entrydate.getText().toString())){
                                                caso="3";
                                            }
                                            if (recievercheckbox.isChecked()){
                                                caso="4";
                                            }
                                            if (entrydatecheckbox.isChecked()&&!TextUtils.isEmpty(entrydate.getText().toString())){
                                                caso="5";
                                            }
                                            if (maturitydatecheckbox.isChecked()&&!TextUtils.isEmpty(matyritydate.getText().toString())){
                                                caso="6";
                                            }
                                            switch (caso){
                                                case "0":
                                                    for (int i=0;i<Tids.size();i++){
                                                        if (!(Transactioninv.get(i).entrydatieedit.equals(entrydate.getText().toString())&&Transactioninv.get(i).maturitydateedit.equals(matyritydate.getText().toString())&&Transactioninv.get(i).recieveredit.equals(recieverspinner.getSelectedItem().toString()))){
                                                            Transactioninv.remove(i);
                                                            Tids.remove(i);
                                                        }
                                                    }
                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                                    break;
                                                case "1":
                                                    for (int i=0;i<Tids.size();i++){
                                                        if (!(Transactioninv.get(i).entrydatieedit.equals(entrydate.getText().toString())&&Transactioninv.get(i).recieveredit.equals(recieverspinner.getSelectedItem().toString()))){
                                                            Transactioninv.remove(i);
                                                            Tids.remove(i);
                                                        }
                                                    }
                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                                    break;
                                                case "2":
                                                    for (int i=0;i<Tids.size();i++){
                                                        if (!(Transactioninv.get(i).maturitydateedit.equals(matyritydate.getText().toString())&&Transactioninv.get(i).recieveredit.equals(recieverspinner.getSelectedItem().toString()))){
                                                            Transactioninv.remove(i);
                                                            Tids.remove(i);
                                                        }
                                                    }
                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                                    break;
                                                case "3":
                                                    for (int i=0;i<Tids.size();i++){
                                                        if (!(Transactioninv.get(i).entrydatieedit.equals(entrydate.getText().toString())&&Transactioninv.get(i).maturitydateedit.equals(matyritydate.getText().toString()))){
                                                            Transactioninv.remove(i);
                                                            Tids.remove(i);
                                                        }
                                                    }
                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                                    break;
                                                case "4":
                                                    for (int i=0;i<Tids.size();i++){
                                                        if (!(Transactioninv.get(i).recieveredit.equals(recieverspinner.getSelectedItem().toString()))){
                                                            Transactioninv.remove(i);
                                                            Tids.remove(i);
                                                        }
                                                    }
                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                                    break;
                                                case "5":
                                                    for (int i=0;i<Tids.size();i++){
                                                        if (!(Transactioninv.get(i).entrydatieedit.equals(entrydate.getText().toString()))){
                                                            Transactioninv.remove(i);
                                                            Tids.remove(i);
                                                        }
                                                    }
                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                                    break;
                                                case "6":
                                                    for (int i=0;i<Tids.size();i++){
                                                        if (!(Transactioninv.get(i).entrydatieedit.equals(entrydate.getText().toString()))){
                                                            Transactioninv.remove(i);
                                                            Tids.remove(i);
                                                        }
                                                    }
                                                    reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                    reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                                    break;
                                                    default:
                                                        reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                        reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));

                                            }

                                        }

                                        @Override
                                        public void onStart() {

                                        }

                                        @Override
                                        public void onFailure() {

                                        }
                                    });
                                }
                                Log.d("ter", "" + Transactioninv.size());
//
                            }

                            @Override
                            public void onStart() {

                            }

                            @Override
                            public void onFailure() {

                            }
                        });
                    }else{
                        if (recievercheckbox.isChecked()){
                            Transactioninv.clear();
                            String inveg = recievergroupid.get(recieveri.indexOf(recieverspinner.getSelectedItem().toString()));
                            String usid = recieveruserid.get(recieveri.indexOf(recieverspinner.getSelectedItem().toString()));
                            Log.d("twoline","abee");
                            readdata(FirebaseDatabase.getInstance().getReference("Allgroups").child(inveg).child(usid), new OnGetDataListner() {
                                @Override
                                public void onSuccess(DataSnapshot dataSnapshot) {
                                    Tids.clear();
                                    for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
                                        Log.d("three",""+dataSnapshot2.getKey());
                                        Tids.add(dataSnapshot2.getKey());
                                    }
                                    Log.d("tidsize", "" + Tids.size());
                                    for (i = 0; i <= Tids.size() - 1; i++) {
                                        readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
                                            @Override
                                            public void onSuccess(DataSnapshot dataSnapshot) {
                                                Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
                                                Log.d("tranv", "" + Transactioninv.size());
                                                Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
                                                reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                            }

                                            @Override
                                            public void onStart() {

                                            }

                                            @Override
                                            public void onFailure() {

                                            }
                                        });
                                    }
                                    Log.d("ter", "" + Transactioninv.size());
//
                                }

                                @Override
                                public void onStart() {

                                }

                                @Override
                                public void onFailure() {

                                }
                            });
                        }else{
                            if (maturitydatecheckbox.isChecked()){
                                if (!TextUtils.isEmpty(matyritydate.getText().toString())) {
                                    Transactioninv.clear();
                                    readdata(FirebaseDatabase.getInstance().getReference("Maturity Dates").child(matyritydate.getText().toString()), new OnGetDataListner() {
                                        @Override
                                        public void onSuccess(DataSnapshot dataSnapshot) {
                                            Tids.clear();
                                            for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
                                                Tids.add(dataSnapshot2.getValue(String.class));
                                            }
                                            Log.d("tidsize", "" + Tids.size());
                                            for (i = 0; i <= Tids.size() - 1; i++) {
                                                readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
                                                    @Override
                                                    public void onSuccess(DataSnapshot dataSnapshot) {
                                                        Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
                                                        Log.d("tranv", "" + Transactioninv.size());
                                                        Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
                                                        reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                        reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                                    }

                                                    @Override
                                                    public void onStart() {

                                                    }

                                                    @Override
                                                    public void onFailure() {

                                                    }
                                                });
                                            }
                                        }

                                        @Override
                                        public void onStart() {

                                        }

                                        @Override
                                        public void onFailure() {

                                        }
                                    });
                                }else {Toast.makeText(Searchactivity.this,"Please select maturity date",Toast.LENGTH_LONG).show();}
                            }else {
                                if (!TextUtils.isEmpty(entrydate.getText().toString())) {
                                    Transactioninv.clear();

                                    readdata(FirebaseDatabase.getInstance().getReference("Entry Dates").child(entrydate.getText().toString()), new OnGetDataListner() {
                                        @Override
                                        public void onSuccess(DataSnapshot dataSnapshot) {
                                            Tids.clear();
                                            for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
                                                Tids.add(dataSnapshot2.getValue(String.class));
                                            }
                                            Log.d("tidsize", "" + Tids.size());
                                            for (i = 0; i <= Tids.size() - 1; i++) {
                                                readdata(FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(Tids.get(i)), new OnGetDataListner() {
                                                    @Override
                                                    public void onSuccess(DataSnapshot dataSnapshot) {
                                                        Transactioninv.add(dataSnapshot.getValue(TransactionentryModel.class));
                                                        Log.d("tranv", "" + Transactioninv.size());
                                                        Log.d("dfjdfi", Transactioninv.get(0).getInvestoredit());
                                                        reciv.setLayoutManager(new LinearLayoutManager(Searchactivity.this));
                                                        reciv.setAdapter(new Searchadapter(Transactioninv,Searchactivity.this,Tids));
                                                    }

                                                    @Override
                                                    public void onStart() {

                                                    }

                                                    @Override
                                                    public void onFailure() {

                                                    }
                                                });
                                            }
                                        }

                                        @Override
                                        public void onStart() {

                                        }

                                        @Override
                                        public void onFailure() {

                                        }
                                    });
                                }else {Toast.makeText(Searchactivity.this,"Please select Entry Date",Toast.LENGTH_LONG).show();}
                            }
                        }
                    }
                }else {
                    Toast.makeText(Searchactivity.this,"Please check a check box",Toast.LENGTH_LONG).show();
                }
            }
        });




    }
    public void readdata(final DatabaseReference reference, final OnGetDataListner listner){
        listner.onStart();
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listner.onSuccess(dataSnapshot);
//                reference.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        listner.onSuccess(dataSnapshot);
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//                        listner.onFailure();
//                    }
//                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar calendar=Calendar.getInstance();
        calendar.set(Calendar.YEAR,year);
        calendar.set(Calendar.MONTH,month);
        calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
        currentDateString= DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        searchi.setText(currentDateString);
    }
    public void newdafor(){
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(
                Searchactivity.this,
                android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                mDateSetListener,
                year,month,day);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
    }




}
