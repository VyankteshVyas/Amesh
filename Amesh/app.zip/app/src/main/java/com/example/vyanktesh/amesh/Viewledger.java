package com.example.vyanktesh.amesh;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Viewledger extends AppCompatActivity {

    Toolbar toolo;
    RecyclerView ledgerrecyclerview;
    List<TransactionentryModel> dataSnapshotList=new ArrayList<>();
    List<String> Tids=new ArrayList<>();
    DatabaseReference Transactionenteries= FirebaseDatabase.getInstance().getReference("Transaction Enteries");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewledger);
        toolo=findViewById(R.id.toolb);
        ledgerrecyclerview=findViewById(R.id.ledgerrecyclerview);
        setSupportActionBar(toolo);
        getSupportActionBar().setTitle("Ledger");
        readdata(Transactionenteries, new OnGetDataListner() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                dataSnapshotList.clear();
                Tids.clear();
                for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                    Tids.add(dataSnapshot1.getKey());
                    dataSnapshotList.add(dataSnapshot1.getValue(TransactionentryModel.class));
                }
                ledgerrecyclerview.setLayoutManager(new LinearLayoutManager(Viewledger.this));
                ledgerrecyclerview.setAdapter(new Searchadapter(dataSnapshotList,Viewledger.this,Tids));
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onFailure() {

            }
        });

    }
    public void readdata(final DatabaseReference reference, final OnGetDataListner listner){
        listner.onStart();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listner.onSuccess(dataSnapshot);
//                reference.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        listner.onSuccess(dataSnapshot);
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//                        listner.onFailure();
//                    }
//                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}
