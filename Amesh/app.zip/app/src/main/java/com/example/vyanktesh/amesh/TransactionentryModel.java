package com.example.vyanktesh.amesh;

public class TransactionentryModel {

    String investoredit,recieveredit,entrydatieedit,maturitydateedit,chequedateedit,amountedit,ROI,Intrestedit,TDS,chequenoedit,Bank,Branch,Brokerage,TDSBrokerage,Remarks,spinnermode,status,investoruid,recieveruid,maturitydateid,entryid,amountid,roiid;

    public TransactionentryModel(){}
    public TransactionentryModel(String investoredit, String recieveredit, String entrydatieedit, String maturitydateedit, String chequedateedit, String amountedit, String ROI, String intrestedit, String TDS, String chequenoedit, String bank, String branch, String brokerage, String TDSBrokerage, String remarks, String spinnermode,String status,String investoruid,String recieveruid,String maturitydateid,String entryid,String amountid,String roiid) {
        this.investoredit = investoredit;
        this.recieveredit = recieveredit;
        this.entrydatieedit = entrydatieedit;
        this.maturitydateedit = maturitydateedit;
        this.chequedateedit = chequedateedit;
        this.amountedit = amountedit;
        this.maturitydateid=maturitydateid;
        this.entryid=entryid;
        this.ROI = ROI;
        Intrestedit = intrestedit;
        this.TDS = TDS;
        this.chequenoedit = chequenoedit;
        Bank = bank;
        Branch = branch;
        Brokerage = brokerage;
        this.TDSBrokerage = TDSBrokerage;
        Remarks = remarks;
        this.spinnermode = spinnermode;
        this.status=status;
        this.investoruid=investoruid;
        this.recieveruid=recieveruid;
        this.amountid=amountid;
        this.roiid=roiid;
    }

    public String getAmountid() {
        return amountid;
    }

    public void setAmountid(String amountid) {
        this.amountid = amountid;
    }

    public String getRoiid() {
        return roiid;
    }

    public void setRoiid(String roiid) {
        this.roiid = roiid;
    }

    public String getMaturitydateid() {
        return maturitydateid;
    }

    public void setMaturitydateid(String maturitydateid) {
        this.maturitydateid = maturitydateid;
    }

    public String getStatus() {
        return status;
    }

    public String getEntryid() {
        return entryid;
    }

    public void setEntryid(String entryid) {
        this.entryid = entryid;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getInvestoruid() {
        return investoruid;
    }

    public void setInvestoruid(String investoruid) {
        this.investoruid = investoruid;
    }

    public String getRecieveruid() {
        return recieveruid;
    }

    public void setRecieveruid(String recieveruid) {
        this.recieveruid = recieveruid;
    }

    public String getInvestoredit() {
        return investoredit;
    }

    public void setInvestoredit(String investoredit) {
        this.investoredit = investoredit;
    }

    public String getRecieveredit() {
        return recieveredit;
    }

    public void setRecieveredit(String recieveredit) {
        this.recieveredit = recieveredit;
    }

    public String getEntrydatieedit() {
        return entrydatieedit;
    }

    public void setEntrydatieedit(String entrydatieedit) {
        this.entrydatieedit = entrydatieedit;
    }

    public String getMaturitydateedit() {
        return maturitydateedit;
    }

    public void setMaturitydateedit(String maturitydateedit) {
        this.maturitydateedit = maturitydateedit;
    }

    public String getChequedateedit() {
        return chequedateedit;
    }

    public void setChequedateedit(String chequedateedit) {
        this.chequedateedit = chequedateedit;
    }

    public String getAmountedit() {
        return amountedit;
    }

    public void setAmountedit(String amountedit) {
        this.amountedit = amountedit;
    }

    public String getROI() {
        return ROI;
    }

    public void setROI(String ROI) {
        this.ROI = ROI;
    }

    public String getIntrestedit() {
        return Intrestedit;
    }

    public void setIntrestedit(String intrestedit) {
        Intrestedit = intrestedit;
    }

    public String getTDS() {
        return TDS;
    }

    public void setTDS(String TDS) {
        this.TDS = TDS;
    }

    public String getChequenoedit() {
        return chequenoedit;
    }

    public void setChequenoedit(String chequenoedit) {
        this.chequenoedit = chequenoedit;
    }

    public String getBank() {
        return Bank;
    }

    public void setBank(String bank) {
        Bank = bank;
    }

    public String getBranch() {
        return Branch;
    }

    public void setBranch(String branch) {
        Branch = branch;
    }

    public String getBrokerage() {
        return Brokerage;
    }

    public void setBrokerage(String brokerage) {
        Brokerage = brokerage;
    }

    public String getTDSBrokerage() {
        return TDSBrokerage;
    }

    public void setTDSBrokerage(String TDSBrokerage) {
        this.TDSBrokerage = TDSBrokerage;
    }

    public String getRemarks() {
        return Remarks;
    }

    public void setRemarks(String remarks) {
        Remarks = remarks;
    }

    public String getSpinnermode() {
        return spinnermode;
    }

    public void setSpinnermode(String spinnermode) {
        this.spinnermode = spinnermode;
    }
}
