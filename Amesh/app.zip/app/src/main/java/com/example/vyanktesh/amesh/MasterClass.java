package com.example.vyanktesh.amesh;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MasterClass extends Fragment {


    DatabaseReference profiledatabaseReference,investordatabaseReference,recieverdatabaseReference,Uspdo;
    Button submit;
    DatabaseReference databaseReference;
    RadioGroup radioGroup;
    LinearLayout selectgrouop;
    RadioButton selectgroupradiobutton,newgrouop,singlegroup;
    Spinner sponi;
    DatabaseReference groups;

    TextView groupnamei;
    EditText partyName, address, mobilenumber, password, PanNo, Bankname, Bnakbranch, accountNumber, Accountname, IFSCcode,Entrydateedit;
    Spinner typespinner;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.masterclass, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        groups= FirebaseDatabase.getInstance().getReference("groups");
        sponi=getActivity().findViewById(R.id.sponi);
        radioGroup=getActivity().findViewById(R.id.radiogrouop);
        selectgrouop=getActivity().findViewById(R.id.selectgrouop);
        selectgroupradiobutton=getActivity().findViewById(R.id.selectgroupradiobutton);
        databaseReference= FirebaseDatabase.getInstance().getReference("groups");

        final String[] requiredradio = new String[1];


        profiledatabaseReference= FirebaseDatabase.getInstance().getReference("Profiles");
        investordatabaseReference= FirebaseDatabase.getInstance().getReference("Investors");
        recieverdatabaseReference= FirebaseDatabase.getInstance().getReference("Recievers");
        Uspdo=FirebaseDatabase.getInstance().getReference("Uspd");
        Log.d("onActivityCreated", "ahagain");
        submit = getActivity().findViewById(R.id.Submit);

        Entrydateedit = getActivity().findViewById(R.id.Entrydateedit);
        partyName = getActivity().findViewById(R.id.Partynameedit);
        address = getActivity().findViewById(R.id.Addressedit);
        mobilenumber = getActivity().findViewById(R.id.Mobileedit);
        PanNo = getActivity().findViewById(R.id.Pannoedit);
        Bankname = getActivity().findViewById(R.id.Banknameedit);
        Bnakbranch = getActivity().findViewById(R.id.BankBranchedit);
        accountNumber = getActivity().findViewById(R.id.AccountNoedit);
        Accountname = getActivity().findViewById(R.id.Accountnameedit);
        IFSCcode = getActivity().findViewById(R.id.IFSCcodeedit);
        typespinner = getActivity().findViewById(R.id.Typespinner);



        final List<String> grouplist=new ArrayList<>();
        final List<String> groupno=new ArrayList<>();
        final List<String> partypelist=new ArrayList<>();

        readdata(groups, new OnGetDataListner() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {

                grouplist.clear();
                groupno.clear();
                partypelist.clear();
                for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                    Log.d("hello",dataSnapshot1.getValue().toString());
                    NewgroupModel nm1=dataSnapshot1.getValue(NewgroupModel.class);

                    grouplist.add(nm1.groupname);
                    groupno.add(nm1.groupadminmobileNumber);
                    Log.d("parttype",nm1.PartyType+"   "+partypelist.size());
                    partypelist.add(nm1.PartyType);



                }
                Log.d("pasize",""+partypelist.size());
                Log.d("stringsize in groupJK:",""+grouplist.size());
                ArrayAdapter<String> arroAdapter=new ArrayAdapter<String>(getActivity(),android.R.layout.simple_spinner_dropdown_item,grouplist);
                sponi.setAdapter(arroAdapter);
            }

            @Override
            public void onStart() {

            }

            @Override
            public void onFailure() {

            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                String radioid =Integer.toString(radioGroup.getCheckedRadioButtonId());
                Log.d("entered","radiogroup");
                if (radioid.equals(Integer.toString(getActivity().findViewById(R.id.selectgroupradiobutton).getId()))){
                    //For selecting a group
                    Log.d("fdfe88",radioid);
                    selectgrouop.setVisibility(View.VISIBLE);
                    submit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (!TextUtils.isEmpty(mobilenumber.getText())&&!TextUtils.isEmpty(partyName.getText())){
                                masterClassModel masterClassModel=new masterClassModel(partyName.getText().toString(),address.getText().toString(), mobilenumber.getText().toString(), PanNo.getText().toString(), Bankname.getText().toString(), Bnakbranch.getText().toString(), accountNumber.getText().toString(), Accountname.getText().toString(), IFSCcode.getText().toString(),groupno.get(grouplist.indexOf(sponi.getSelectedItem().toString())),Entrydateedit.getText().toString(),typespinner.getSelectedItem().toString(),"Not group Admin");
                                profiledatabaseReference.child(mobilenumber.getText().toString()).setValue(masterClassModel);

                                if (typespinner.getSelectedItem().toString().equals("Investor")){
                                    InvestorMode investorMode=new InvestorMode(groupno.get(grouplist.indexOf(sponi.getSelectedItem().toString())),partyName.getText().toString());
                                    investordatabaseReference.child(mobilenumber.getText().toString()).setValue(investorMode);

                                }
                                if (typespinner.getSelectedItem().toString().equals("Reciever")){
                                    RecieverModel recieverModel=new RecieverModel(groupno.get(grouplist.indexOf(sponi.getSelectedItem().toString())),partyName.getText().toString());
                                    recieverdatabaseReference.child(mobilenumber.getText().toString()).setValue(recieverModel);

                                }

                                FragmentManager manager = getFragmentManager();
                                FragmentTransaction transaction = manager.beginTransaction();
                                manager.popBackStack("admintogroup", manager.POP_BACK_STACK_INCLUSIVE);
                                transaction.commit();
                            }else {
                                Toast.makeText(getActivity(),"Please Enter Mobile Number and party name",Toast.LENGTH_SHORT).show();}
                        }
                    });

                }
                if (radioid.equals(Integer.toString(getActivity().findViewById(R.id.singlemembergrou).getId()))){
                    //For single member group
                    Log.d("fdfe88",radioid);
                    selectgrouop.setVisibility(View.INVISIBLE);
                    submit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (!TextUtils.isEmpty(mobilenumber.getText())&&!TextUtils.isEmpty(partyName.getText())){
                                masterClassModel masterClassModel=new masterClassModel(partyName.getText().toString(),address.getText().toString(), mobilenumber.getText().toString(), PanNo.getText().toString(), Bankname.getText().toString(), Bnakbranch.getText().toString(), accountNumber.getText().toString(), Accountname.getText().toString(), IFSCcode.getText().toString(),mobilenumber.getText().toString(),Entrydateedit.getText().toString(),typespinner.getSelectedItem().toString(),"Group Admin");
                                profiledatabaseReference.child(mobilenumber.getText().toString()).setValue(masterClassModel);

                                if (typespinner.getSelectedItem().toString().equals("Investor")){
                                    InvestorMode investorMode=new InvestorMode(mobilenumber.getText().toString(),partyName.getText().toString());
                                    investordatabaseReference.child(mobilenumber.getText().toString()).setValue(investorMode);

                                }
                                if (typespinner.getSelectedItem().toString().equals("Reciever")){
                                    RecieverModel recieverModel=new RecieverModel(mobilenumber.getText().toString(),partyName.getText().toString());
                                    recieverdatabaseReference.child(mobilenumber.getText().toString()).setValue(recieverModel);

                                }

                                FragmentManager manager = getFragmentManager();
                                FragmentTransaction transaction = manager.beginTransaction();
                                manager.popBackStack("admintogroup", manager.POP_BACK_STACK_INCLUSIVE);
                                transaction.commit();
                            }else {
                                Toast.makeText(getActivity(),"Please Enter Mobile Number and party name",Toast.LENGTH_SHORT).show();}
                        }
                    });
                }
                if (radioid.equals(Integer.toString(getActivity().findViewById(R.id.newgru).getId()))){
                    Log.d("fdfe88",radioid);
                    selectgrouop.setVisibility(View.INVISIBLE);



                    submit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (!TextUtils.isEmpty(mobilenumber.getText())&&!TextUtils.isEmpty(partyName.getText())){
                                masterClassModel masterClassModel=new masterClassModel(partyName.getText().toString(),address.getText().toString(), mobilenumber.getText().toString(), PanNo.getText().toString(), Bankname.getText().toString(), Bnakbranch.getText().toString(), accountNumber.getText().toString(), Accountname.getText().toString(), IFSCcode.getText().toString(),mobilenumber.getText().toString(),Entrydateedit.getText().toString(),typespinner.getSelectedItem().toString(),"Group Admin");
                                profiledatabaseReference.child(mobilenumber.getText().toString()).setValue(masterClassModel);
                                NewgroupModel newgroupModel = new NewgroupModel(partyName.getText().toString(), mobilenumber.getText().toString(),typespinner.getSelectedItem().toString());
                                databaseReference.child(mobilenumber.getText().toString()).setValue(newgroupModel);

                                if (typespinner.getSelectedItem().toString().equals("Investor")){
                                    InvestorMode investorMode=new InvestorMode(mobilenumber.getText().toString(),partyName.getText().toString());
                                    investordatabaseReference.child(mobilenumber.getText().toString()).setValue(investorMode);

                                }
                                if (typespinner.getSelectedItem().toString().equals("Reciever")){
                                    RecieverModel recieverModel=new RecieverModel(mobilenumber.getText().toString(),partyName.getText().toString());
                                    recieverdatabaseReference.child(mobilenumber.getText().toString()).setValue(recieverModel);

                                }

                                FragmentManager manager = getFragmentManager();
                                FragmentTransaction transaction = manager.beginTransaction();
                                manager.popBackStack("admintogroup", manager.POP_BACK_STACK_INCLUSIVE);
                                transaction.commit();
                            }else {
                                Toast.makeText(getActivity(),"Please Enter Mobile Number and party name",Toast.LENGTH_SHORT).show();}
                        }
                    });

                }

                requiredradio[0] =Integer.toString(selectgroupradiobutton.getId());
                Log.d("ohmod",""+ radioid +"  "+ requiredradio[0]);

            }
        });





    }
    public void readdata(final DatabaseReference reference, final OnGetDataListner listner){
        listner.onStart();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listner.onSuccess(dataSnapshot);
//                reference.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        listner.onSuccess(dataSnapshot);
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//                        listner.onFailure();
//                    }
//                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

//    @Override
//    public void onResume() {
//        super.onResume();
//        Log.d("group name0 aaya kya",""+groupname);

//    }

//    @Override
//    public void onStart() {
//        super.onStart();
//        Log.d("Starti","chala"+groupname);
//
//    }

//    public void passgroupname(String groupname) {
////        this.groupname=groupname;
////        groupnamei.setText("oh god");
//            Log.d("value aai kya",groupname);
//    }

}
