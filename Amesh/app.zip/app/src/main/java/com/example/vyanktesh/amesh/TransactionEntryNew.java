package com.example.vyanktesh.amesh;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class TransactionEntryNew extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private static final String TAG = "MainActivity";
    DatabaseReference Allgroups,TransactionEntries,EntryDates,MaturityDates,Amounts,Investors,Recievers,Rateofintrest;
    String currentDateString;
    List<String> investori=new ArrayList<>();
    List<String> recieveri=new ArrayList<>();
    List<String> investorgroupid=new ArrayList<>();
    List<String> investoruserid=new ArrayList<>();
    List<String> recievergroupid=new ArrayList<>();
    List<String> recieveruserid=new ArrayList<>();
    String idOfClickedItem;
    AutoCompleteTextView investoredit,recieveredit;
    TextView entrydatieedit,maturitydateedit,chequedateedit;
    TextView hiddenreciever,hiddeninvestor,hiddenentrydate;
    EditText amountedit,ROI,Intrestedit,TDS,chequenoedit,Bank,Branch,Brokerage,TDSBrokerage,Remarks;
    Spinner spinnermode;
    ProgressBar progressBar;
    Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Firebase.setAndroidContext(this);
        setContentView(R.layout.activity_transaction_entry_new);
        investoredit=findViewById(R.id.investoredit);
        recieveredit=findViewById(R.id.recieveredit);
        entrydatieedit=findViewById(R.id.Entrydateedit);
        maturitydateedit=findViewById(R.id.Maturitydateedit);
        amountedit=findViewById(R.id.amountdit);
        ROI=findViewById(R.id.ROIedit);
        TDS=findViewById(R.id.TDSedit);
        spinnermode=findViewById(R.id.spinnermode);
        chequenoedit=findViewById(R.id.Chequenoedit);
        Intrestedit=findViewById(R.id.intrestedit);
        chequedateedit=findViewById(R.id.Chequedateedit);
        Bank=findViewById(R.id.Bankedit);
        Branch=findViewById(R.id.Branchedit);
        Brokerage=findViewById(R.id.Brokerageedit);
        TDSBrokerage=findViewById(R.id.TDSBrokerageedit);
        Remarks=findViewById(R.id.Remarksedit);
        submit=findViewById(R.id.submittransactiontofirebase);
        progressBar =findViewById(R.id.progressBar2);
        progressBar.setIndeterminate(true);
        Investors=FirebaseDatabase.getInstance().getReference("Investors");
        Recievers=FirebaseDatabase.getInstance().getReference("Recievers");
        Allgroups=FirebaseDatabase.getInstance().getReference("Allgroups");
        TransactionEntries=FirebaseDatabase.getInstance().getReference("Transaction Enteries");
        EntryDates=FirebaseDatabase.getInstance().getReference("Entry Dates");
        MaturityDates=FirebaseDatabase.getInstance().getReference("Maturity Dates");
        Amounts=FirebaseDatabase.getInstance().getReference("Amount Enteries");
        Rateofintrest=FirebaseDatabase.getInstance().getReference("Rate Of Intrests");
        hiddeninvestor=findViewById(R.id.hiddeninvestor);
        hiddenreciever=findViewById(R.id.hiddenreciever);
        String verify=getIntent().getStringExtra("verify");
        if (verify.equals("1")){
            final String transactionidhidden=getIntent().getStringExtra("transactionidhidden");
            hiddenreciever.setVisibility(View.VISIBLE);
            hiddeninvestor.setVisibility(View.VISIBLE);
            String investornamehidden=getIntent().getStringExtra("investornamehidden");
            String recievernamehidden=getIntent().getStringExtra("recievernamehidden");
            final String maturityid=getIntent().getStringExtra("maturitydateid");
            final String hiddeninvestoruid=getIntent().getStringExtra("investoruid");
            final String hiddenrecieveruid=getIntent().getStringExtra("recieveruid");
            final String entryid=getIntent().getStringExtra("entryid");
            final String hiddenmaturitydate=getIntent().getStringExtra("maturitydatehidden");
            final String hiddenentrydate=getIntent().getStringExtra("entrydatehidden");
            final String amountid=getIntent().getStringExtra("amountid");
            final String roiid=getIntent().getStringExtra("roiid");
            final String hiddenamount=getIntent().getStringExtra("amounthidden");
            final String hiddenroi=getIntent().getStringExtra("roihidden");
            hiddenreciever.setText(recievernamehidden);
            hiddeninvestor.setText(investornamehidden);
            entrydatieedit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            month = month + 1;
                            Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                            String date = day + "-" + month + "-" + year;
                            entrydatieedit.setText(date);
                        }
                    };
                    newdafor();
                }
            });
            maturitydateedit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            month = month + 1;
                            Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                            String date = day + "-" + month + "-" + year;
                            maturitydateedit.setText(date);
                        }
                    };
                    newdafor();
                }
            });
            chequedateedit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            month = month + 1;
                            Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                            String date = day + "-" + month + "-" + year;
                            chequedateedit.setText(date);
                        }
                    };
                    newdafor();
                }
            });
            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    submit.setEnabled(false);
                    String pushkey=FirebaseDatabase.getInstance().getReference("PreMaturitydates").child(transactionidhidden).push().getKey();
                    moveFirebaseRecord(new Firebase("https://amesh-e678e.firebaseio.com/Transaction Enteries/"+transactionidhidden),new Firebase("https://amesh-e678e.firebaseio.com/PreMaturitydates/"+transactionidhidden+"/"+pushkey));
                    MaturityDates.child(hiddenmaturitydate).child(maturityid).setValue(null);
                    EntryDates.child(hiddenentrydate).child(entryid).setValue(null);
                    Amounts.child(hiddenamount).child(amountid).setValue(null);
                    Rateofintrest.child(hiddenroi).child(roiid).setValue(null);
                    Log.d("1stline",""+hiddenmaturitydate+"{{{"+maturityid);
                    String ama = MaturityDates.child(maturitydateedit.getText().toString()).push().getKey();
                    String eama=EntryDates.child(entrydatieedit.getText().toString()).push().getKey();
                    String newamountid=Amounts.child(amountedit.getText().toString()).push().getKey();
                    String newroiid=Rateofintrest.child(ROI.getText().toString()).push().getKey();
                    Log.d("ama ki value",""+ama);
                    MaturityDates.child(maturitydateedit.getText().toString()).child(ama).setValue(transactionidhidden);
                    EntryDates.child(entrydatieedit.getText().toString()).child(eama).setValue(transactionidhidden);
                    Rateofintrest.child(ROI.getText().toString()).child(newroiid).setValue(transactionidhidden);
                    Amounts.child(amountedit.getText().toString()).child(newamountid).setValue(transactionidhidden);
                    final TransactionentryModel transactionentryModel1=new TransactionentryModel(hiddeninvestor.getText().toString(),hiddenreciever.getText().toString(),entrydatieedit.getText().toString(),maturitydateedit.getText().toString(),chequedateedit.getText().toString(),amountedit.getText().toString(),ROI.getText().toString(),Intrestedit.getText().toString(),TDS.getText().toString(),chequenoedit.getText().toString(),Bank.getText().toString(),Branch.getText().toString(),Brokerage.getText().toString(),TDSBrokerage.getText().toString(),Remarks.getText().toString(),spinnermode.getSelectedItem().toString(),"active",hiddeninvestoruid,hiddenrecieveruid,ama,eama,newamountid,newroiid);

                    FirebaseDatabase.getInstance().getReference("Transaction Enteries").child(transactionidhidden).setValue(transactionentryModel1);
                }
            });


        }else {
            readdata(Investors, new OnGetDataListner() {
                @Override
                public void onSuccess(DataSnapshot dataSnapshot) {
                    Log.d("iiu","oid");
                    investori.clear();
                    investorgroupid.clear();
                    investoruserid.clear();
                    for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                        InvestorMode invo=dataSnapshot1.getValue(InvestorMode.class);
                        investori.add(invo.userName);
                        investoruserid.add(dataSnapshot1.getKey());
                        investorgroupid.add(invo.Groupid);
                    }
                }

                @Override
                public void onStart() {

                }

                @Override
                public void onFailure() {

                }
            });
            readdata(Recievers, new OnGetDataListner() {
                @Override
                public void onSuccess(DataSnapshot dataSnapshot) {
                    recieveri.clear();
                    recievergroupid.clear();
                    recieveruserid.clear();
                    for (DataSnapshot recovo: dataSnapshot.getChildren()){
                        RecieverModel recieverModel=recovo.getValue(RecieverModel.class);
                        recieveri.add(recieverModel.userName);
                        recieveruserid.add(recovo.getKey());
                        recievergroupid.add(recieverModel.Groupid);
                    }
                    progressBar.setVisibility(View.INVISIBLE);
                }

                @Override
                public void onStart() {

                }

                @Override
                public void onFailure() {

                }
            });
            ArrayAdapter investoradapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,investori);
            investoredit.setAdapter(investoradapter);

            ArrayAdapter recieveradapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,recieveri);
            recieveredit.setAdapter(recieveradapter);


            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!TextUtils.isEmpty(recieveredit.getText())&&!TextUtils.isEmpty(investoredit.getText())&&!TextUtils.isEmpty(amountedit.getText())&&!TextUtils.isEmpty(maturitydateedit.getText())&&!TextUtils.isEmpty(entrydatieedit.getText())) {
                        submit.setEnabled(false);

                        Log.d("recie", "onClick: " + "''" + recievergroupid.get(recieveri.indexOf(recieveredit.getText().toString())) + ";;" + recieveruserid.get(recieveri.indexOf(recieveredit.getText().toString())));
                        Log.d("hello", "hai");
                        String transactionid=TransactionEntries.push().getKey();
                        String maturityid=MaturityDates.push().getKey();
                        String entryid=EntryDates.push().getKey();
                        String amountid=Amounts.push().getKey();
                        String  roiid=Rateofintrest.push().getKey();

                        TransactionentryModel transactionentryModel=new TransactionentryModel(investoredit.getText().toString(),recieveredit.getText().toString(),entrydatieedit.getText().toString(),maturitydateedit.getText().toString(),chequedateedit.getText().toString(),amountedit.getText().toString(),ROI.getText().toString(),Intrestedit.getText().toString(),TDS.getText().toString(),chequenoedit.getText().toString(),Bank.getText().toString(),Branch.getText().toString(),Brokerage.getText().toString(),TDSBrokerage.getText().toString(),Remarks.getText().toString(),spinnermode.getSelectedItem().toString(),"Active",investoruserid.get(investori.indexOf(investoredit.getText().toString())),recieveruserid.get(recieveri.indexOf(recieveredit.getText().toString())),maturityid,entryid,amountid,roiid);
                        MaturityDates.child(maturitydateedit.getText().toString()).child(maturityid).setValue(transactionid);
                        EntryDates.child(entrydatieedit.getText().toString()).child(entryid).setValue(transactionid);
                        Amounts.child(amountedit.getText().toString()).child(amountid).setValue(transactionid);
                        Rateofintrest.child(ROI.getText().toString()).child(roiid).setValue(transactionid);
                        TransactionEntries.child(transactionid).setValue(transactionentryModel);
                        FirebaseDatabase.getInstance().getReference("PreMaturitydates").child(transactionid).push().setValue(transactionentryModel);
                        Allgroups.child(investorgroupid.get(investori.indexOf(investoredit.getText().toString()))).child(investoruserid.get(investori.indexOf(investoredit.getText().toString()))).child(transactionid).setValue("active");
                        Allgroups.child(recievergroupid.get(recieveri.indexOf(recieveredit.getText().toString()))).child(recieveruserid.get(recieveri.indexOf(recieveredit.getText().toString()))).child(transactionid).setValue("active");
//                Allgroups.child(recievergroupid.get(recieveri.indexOf(recieveredit.getText().toString()))).child()
//                Allgroups.getDatabase().getReference(investorgroupid.get(investori.indexOf(investoredit.getText().toString()))).child(investoruserid.get(investori.indexOf(investoredit.getText().toString()))).child(transactionid).setValue("Active");
//                Allgroups.getDatabase().getReference(recievergroupid.get(recieveri.indexOf(recieveredit.getText().toString()))).child(recieveruserid.get(recieveri.indexOf(recieveredit.getText().toString()))).child(transactionid).setValue("Active");
//                Log.d("djfkdj",""+investorgroupid.get(investori.indexOf(investoredit.getText().toString())));

                    }else {Toast.makeText(TransactionEntryNew.this,"Please make sure if maturity date,entry date, amount, reciver and investor are filled",Toast.LENGTH_LONG).show();}
                }
            });




            entrydatieedit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            month = month + 1;
                            Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                            String date = day + "-" + month + "-" + year;
                            entrydatieedit.setText(date);
                        }
                    };
                    newdafor();
                }
            });
            maturitydateedit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            month = month + 1;
                            Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                            String date = day + "-" + month + "-" + year;
                            maturitydateedit.setText(date);
                        }
                    };
                    newdafor();
                }
            });
            chequedateedit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            month = month + 1;
                            Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                            String date = day + "-" + month + "-" + year;
                            chequedateedit.setText(date);
                        }
                    };
                    newdafor();
                }
            });
        }



    }

    public void readdata(final DatabaseReference reference, final OnGetDataListner listner){
        listner.onStart();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                listner.onSuccess(dataSnapshot);
//                reference.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(DataSnapshot dataSnapshot) {
//                        listner.onSuccess(dataSnapshot);
//                    }
//
//                    @Override
//                    public void onCancelled(DatabaseError databaseError) {
//                        listner.onFailure();
//                    }
//                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }


    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar calendar=Calendar.getInstance();
        calendar.set(Calendar.YEAR,year);
        calendar.set(Calendar.MONTH,month);
        calendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
        currentDateString= DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        switch(idOfClickedItem)
        {
            case "2131230743":
                Log.d("curri",currentDateString);
                entrydatieedit.setText(currentDateString);
                break;
            case "2131230749":
                maturitydateedit.setText(currentDateString);
                break;
            case "2131230739":
                chequedateedit.setText(currentDateString);
                break;
            default:
                System.out.println("no match");
        }

    }
    public void newdafor() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(
                TransactionEntryNew.this,
                android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                mDateSetListener,
                year, month, day);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
    }
    public static void moveFirebaseRecord(Firebase fromPath, final Firebase toPath)
    {
        fromPath.addListenerForSingleValueEvent(new com.firebase.client.ValueEventListener() {
            @Override
            public void onDataChange(com.firebase.client.DataSnapshot dataSnapshot) {
                toPath.setValue(dataSnapshot.getValue(), new Firebase.CompletionListener()
                {
                    @Override
                    public void onComplete(FirebaseError firebaseError, Firebase firebase)
                    {
                        if (firebaseError != null)
                        {
                            System.out.println("Copy failed");
                        }
                        else
                        {
                            System.out.println("Success");
                        }
                    }
                });
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {
                System.out.println("Copy failed");
            }
        });
    }
//    class ourdataloadupdate extends AsyncTask<Void,Integer,Integer>{
//        @Override
//        protected void onPreExecute() {
//            super.onPreExecute();
//            progressBar.setMax(100);
//        }
//
//        @Override
//        protected void onProgressUpdate(Integer... values) {
//            super.onProgressUpdate(values);
//            progressBar.setProgress(values[0]);
//        }
//
//        @Override
//        protected Integer doInBackground(Void... voids) {
//            for (int i=0;i<100;i++){
//                publishProgress(i);
//            }
//            return null;
//        }
//
//        @Override
//        protected void onPostExecute(Integer integer) {
//            super.onPostExecute(integer);
//        }
//    }
}
