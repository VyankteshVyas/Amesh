package com.example.vyanktesh.amesh;

public class Uspd {
    String Password,Type,Groupid;
    public Uspd(){}
    public Uspd(String Password,String Type,String Groupid){
        this.Password=Password;
        this.Type=Type;
        this.Groupid=Groupid;
    }

    public String getGroupid() {
        return Groupid;
    }

    public void setGroupid(String groupid) {
        Groupid = groupid;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }
}
