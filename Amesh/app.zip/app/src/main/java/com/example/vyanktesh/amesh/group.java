package com.example.vyanktesh.amesh;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class group extends Fragment{



    ListView listView;
    Button createNewGroup;
    List<String> grouplist=new ArrayList<>();
    List<String> groupno=new ArrayList<>();
    List<String> partypelist=new ArrayList<>();
    DatabaseReference groups;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.group,container,false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
       listView=getActivity().findViewById(R.id.listi);
       createNewGroup=getActivity().findViewById(R.id.createNewGroup);
       groups= FirebaseDatabase.getInstance().getReference("groups");
       String hai=getContext().toString();
       Log.d("context vali",hai);
       createNewGroup.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               NewGroup newGroup=new NewGroup();
               FragmentManager manager=getFragmentManager();
               FragmentTransaction transaction=manager.beginTransaction();
               transaction.add(R.id.rellayout,newGroup,"newgroupfragment");
               transaction.addToBackStack("group to newgroup");
               transaction.commit();

           }
       });


    }

    @Override
    public void onStart() {
        super.onStart();
        groups.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                grouplist.clear();
                groupno.clear();
                partypelist.clear();
                for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                    Log.d("hello",dataSnapshot1.getValue().toString());
                    NewgroupModel nm1=dataSnapshot1.getValue(NewgroupModel.class);

                    grouplist.add(nm1.groupname);
                    groupno.add(nm1.groupadminmobileNumber);
                    Log.d("parttype",nm1.PartyType+"   "+partypelist.size());
                    partypelist.add(nm1.PartyType);



                }
                Log.d("pasize",""+partypelist.size());
                Log.d("stringsize in groupJK:",""+grouplist.size());
                ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,grouplist);
                listView.setAdapter(arrayAdapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        FragmentManager manager=getFragmentManager();
                        Bundle args=new Bundle();
                        args.putString("groupname",grouplist.get(position));
                        args.putString("adminno",groupno.get(position));
                        args.putString("partytype",partypelist.get(position));



                    }
                });

//                recyclerView.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Log.d("groupkeandaronclick", "onClick: ");
//                        MasterClass masterClass=new MasterClass();
//                        FragmentManager manager=getFragmentManager();
//                        FragmentTransaction transaction=manager.beginTransaction();
//                        transaction.replace(R.id.rellayout,masterClass);
//                        transaction.commit();
//                    }
//                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }


    public void passgroupname(String groupname) {
    }


}
